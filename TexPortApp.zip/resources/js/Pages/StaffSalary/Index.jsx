import { useState } from 'react';
import { Head } from '@inertiajs/react';
import Sidebar from '@/Components/Sidebar';
import DashboardHeader from '@/Components/DashboardHeader';
import DataTable from '@/Components/DataTable';
import Button from '@/Components/Button';
import { MdAdd } from 'react-icons/md';
import StaffSalaryModal from './StaffSalaryModal';
import StaffSalaryActions from './StaffSalaryActions';
import { staffSalaryColumns } from './staffSalaryConfig';
import { usePermissions } from '@/Utils/permissions';
import Toast from '@/Components/Toast';
import { useToastFlash } from '@/Hooks/useToastFlash';

export default function StaffSalaryIndex(props) {
    const { auth = {}, salaries = {}, filters = {}, staffList = [] } = props;
    const { canCreate, canEdit, canDelete, hasAnyAction } = usePermissions();

    useToastFlash();

    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [modalState, setModalState] = useState({ isOpen: false, mode: null, entity: null });

    const handleEdit = (item) => {
        setModalState({ isOpen: true, mode: 'edit', entity: item });
    };

    const handleDelete = (item) => {
        setModalState({ isOpen: true, mode: 'delete', entity: item });
    };

    const breadcrumbs = [
        { label: 'Dashboard', href: route('dashboard') },
        { label: 'Staff' },
        { label: 'Staff Salaries' }
    ];

    return (
        <>
            <Head title="Staff Salaries" />

            <div className="flex h-screen bg-background">
                <Sidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} user={auth.user} />

                <div className="flex-1 flex flex-col overflow-hidden">
                    <DashboardHeader
                        user={auth.user}
                        onMenuClick={() => setSidebarOpen(true)}
                        breadcrumbs={breadcrumbs}
                    />

                    <main className="flex-1 overflow-y-auto p-4 lg:p-6">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 lg:mb-8 space-y-4 sm:space-y-0">
                            <h1 className="text-xl lg:text-2xl font-bold text-text">Staff Salaries</h1>
                            {canCreate('staff salary') && (
                                <Button
                                    className="flex items-center space-x-2"
                                    tooltip="Add Staff Salary"
                                    onClick={() => setModalState({ isOpen: true, mode: 'create', entity: null })}
                                >
                                    <MdAdd className="w-5 h-5" />
                                    <span>Add Salary</span>
                                </Button>
                            )}
                        </div>

                        <DataTable
                            data={salaries.data}
                            columns={[
                                ...staffSalaryColumns,
                                ...(hasAnyAction('staff salary') ? [{
                                    key: "actions",
                                    label: "Actions",
                                    render: (item) => (
                                        <StaffSalaryActions
                                            item={item}
                                            onEdit={handleEdit}
                                            onDelete={handleDelete}
                                        />
                                    ),
                                }] : []),
                            ]}
                            searchPlaceholder="Search by staff name, date, or salary..."
                            filters={filters}
                            pagination={salaries}
                        />

                        <StaffSalaryModal
                            isOpen={modalState.isOpen}
                            onClose={() => setModalState({ isOpen: false, mode: null, entity: null })}
                            mode={modalState.mode}
                            entity={modalState.entity}
                            staffList={staffList}
                        />
                    </main>
                </div>
            </div>

            <Toast />
        </>
    );
}